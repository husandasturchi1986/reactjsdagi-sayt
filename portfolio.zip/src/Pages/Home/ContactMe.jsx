export default function ContactMe() {
    return (
      <section id="Contact" className="contact--section">
        <div>
          <p className="sub--title">Murojaat yo`llash</p>
          <h2>Menga murojaat yo`llang</h2>
          <p className="text-lg">
            Barcha savollaringizga qisqa fursatda javob beraman.
          </p>
        </div>
        <form className="contact--form--container">
          <div className="container">
            <label htmlFor="first-name" className="contact--label">
              <span className="text-md">Ismingiz</span>
              <input
                type="text"
                className="contact--input text-md"
                name="first-name"
                id="first-name"
                required
              />
            </label>
            <label htmlFor="last-name" className="contact--label">
              <span className="text-md">Familiyangiz</span>
              <input
                type="text"
                className="contact--input text-md"
                name="last-name"
                id="last-name"
                required
              />
            </label>
            <label htmlFor="email" className="contact--label">
              <span className="text-md">Elektron manzilingiz</span>
              <input
                type="email"
                className="contact--input text-md"
                name="email"
                id="email"
                required
              />
            </label>
            <label htmlFor="phone-number" className="contact--label">
              <span className="text-md">Telefon raqamingiz</span>
              <input
                type="number"
                className="contact--input text-md"
                name="phone-number"
                id="phone-number"
                required
              />
            </label>
          </div>
          <label htmlFor="choode-topic" className="contact--label">
            <span className="text-md">Tanlang...</span>
            <select id="choose-topic" className="contact--input text-md">
              <option>Tanlang...</option>
              <option>Taklif</option>
              <option>Shikoyat</option>
              <option>Murojaat</option>
            </select>
          </label>
          <label htmlFor="message" className="contact--label">
            <span className="text-md">Murojaat</span>
            <textarea
              className="contact--input text-md"
              id="message"
              rows="8"
              placeholder="Murojaat mazmunini yozing..."
            />
          </label>
          <label htmlFor="checkboc" className="checkbox--label">
            <input type="checkbox" required name="checkbox" id="checkbox" />
            <span className="text-sm">O`zimning shaxsimni tasdiqlayman</span>
          </label>
          <div>
            <button className="btn btn-primary contact--form--btn">Jo`natish</button>
          </div>
        </form>
      </section>
    );
  }
  